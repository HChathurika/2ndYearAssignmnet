package application;

import dao.CurrencyDao;
import entity.Currency;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;

public class CurrencyAppGUI extends Application {

    private CurrencyDao dao = new CurrencyDao();
    private TableView<Currency> table = new TableView<>();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Currency Converter");

        // ID column
        TableColumn<Currency, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getId()).asObject());

        // Code column
        TableColumn<Currency, String> codeCol = new TableColumn<>("Code");
        codeCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCode()));

        // Name column
        TableColumn<Currency, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getName()));

        // Rate column
        TableColumn<Currency, Double> rateCol = new TableColumn<>("Rate");
        rateCol.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getRate()).asObject());

        table.getColumns().addAll(idCol, codeCol, nameCol, rateCol);

        Button loadBtn = new Button("Load Currencies");
        loadBtn.setOnAction(e -> loadCurrencies());

        VBox root = new VBox(10, table, loadBtn);
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }

    private void loadCurrencies() {
        ObservableList<Currency> list = FXCollections.observableArrayList(dao.findAll());
        table.setItems(list);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
