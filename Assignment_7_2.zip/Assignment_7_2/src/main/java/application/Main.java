package application;

public class Main {
    public static void main(String[] args) {
        // Forward execution to CurrencyApp
        CurrencyApp.main(args);
    }
}

