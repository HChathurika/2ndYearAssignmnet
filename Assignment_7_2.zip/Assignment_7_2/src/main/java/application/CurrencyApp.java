package application;

import dao.CurrencyDao;

import java.util.Scanner;

public class CurrencyApp {

    public static void main(String[] args) {

        CurrencyDao currencyDao = new CurrencyDao();
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Currency Converter ===");

        System.out.print("Enter the currency abbreviation (e.g., USD, EUR): ");
        String currency = scanner.nextLine();

        System.out.print("Enter the amount to convert: ");
        double amount = 0.0;

        try {
            amount = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number entered!");
            return;
        }

        try {
            // Fetch exchange rate from the database
            double rate = currencyDao.getExchangeRate(currency);
            double converted = amount * rate;
            System.out.println(amount + " " + currency + " = " + converted + " in base currency.");
        } catch (Exception e) {
            System.out.println("Error: Could not fetch exchange rate from database.");
            e.printStackTrace();
        }

        // Close DB connection
        datasource.MariaDbConnection.terminate();
        scanner.close();
    }
}
